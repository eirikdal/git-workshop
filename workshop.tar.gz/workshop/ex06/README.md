Bjarne har mistet en commit. Hjelp han aa finne den igjen og legg den paa master (medium).

Hint:

Bruk gjerne "git rebase" for aa legge den paa master igjen naar du har funnet commiten. Her kan
vi tillate oss litt juks!
