Lag en ny branch med minst en commit uten aa bruke "git add", "git commit" eller "git checkout"

Hint:

