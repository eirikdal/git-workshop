Bjarne har lagd en feature-branch, men han har gjort noe feil. Egentlig ville han branche ut fra master, men naa er alt galt. Hjelp han aa redde situasjonen..

Hint:

git rebase
