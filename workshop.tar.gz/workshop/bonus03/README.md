Som en god soldat saa er du disiplinert og committer ofte. Naa er det tid
for aa pushe endringene dine til repo, og du innser at det blir litt rotete
med saa mange commits. Du vil gjerne rydde opp litt i historikken din foer du pusher.
Finn ut hvordan du kan slaa sammen committene dine, og gi de bedre navn!

Hint: Rebase
