Du og din kollega jobber paa et prosjekt og du har nettopp gjort en endring som du gjerne vil pushe til Git, men
Git lar deg ikke pushe. Finn ut hva som er feil og fiks det!
