Freddy Hipster har lagt sin private ssh nokkel i repo, og naa trenger han din hjelp til aa finne den igjen.
