Klok av skade har Freddy har kommet opp med en ny og lur for å finne igjen SSH nøkkelen sin i repo.

Hva har han gjort?
