Du har gjort en commit og vil gjerne pushe denne til master, men Git vil ikke la deg pushe. Finn ut hva som er feil og fiks det!
