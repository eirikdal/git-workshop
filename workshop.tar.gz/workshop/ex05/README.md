Bjarne oppdager til sin store forundring at Git lager kopier av alle filene hans i stedet for aa lagre kun endringene.

Hjelp han aa finne ut av hva som skjer:

Hvor stor er objektet som Git har lagret?
Hvor stor er objektet etter at du har commitet en endring paa filen?

Hint:

* git count-objects -Hv
* git filter-branch (--

Etter at du har fjernet filen fra repository saa ligger filen fortsatt aa lurer et sted. Du maa sannsynlig fjerne
denne paa den litt mer tradisjonelle maaten.
