Bjarne oppdager til sin store forundring at Git lager kopier av alle filene hans i stedet for aa lagre kun endringene.

Hjelp han aa finne ut av hva som skjer:

Hvor mye plass bruker Git før du gjør endringen i filen?
Hvor mye plass bruker Git etter at du har gjort en endring av filen?
Hvor er det blitt av opprinnelige filen?

