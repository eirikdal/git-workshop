Lag et repository uten aa bruke "git init"

Hint:

Git behøver som minimum et sted å oppbevare objekter og referanser. Den trenger også å vite hvor i verden den står.
