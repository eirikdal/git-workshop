Lag et repository uten aa bruke "git init"

Hint:

Som et minimum maa et git repo ha disse mappene og filene:

.git/refs/heads
.git/objects
.git/HEAD
