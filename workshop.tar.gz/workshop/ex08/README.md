Freddy Hipster angrer dypt paa at han committet sin private ssh noekkel i et opensource repo paa github.
Kan du hjelpe han aa fjerne den fra historikken helt?

Sammenlign sha1-hashkodene etterpaa. Har noe endret seg?

Hint: git filter-branch
