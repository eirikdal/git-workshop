Lag minst 2 commits paa master uten aa bruke "git add" og "git commit"

Kontroller resultatet med "git log".

Hint:

Du maa ha en fil i staging area og filen maa tilhore et tre foer du kan lage en commit.
