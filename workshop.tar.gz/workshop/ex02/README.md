Legg en fil i staging area uten aa lage en fil, og uten aa bruke "git add"

Hint:

For aa legge en fil i staging area maa Git kjenne til et objekt av type blob. Du maa ogsaa oppdatere indexen.
